function randomResponse(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function daruratMessage(sapaan, nama) {
    const responses = [
        `Terimakasih ${sapaan} ${nama} telah menghubungi kami.
            Karna situasi nya darurat jadi silahkan untuk langsung hubungi:

            - 119 : PSC  (Untuk Kegawat Daruratan Medis)
            - 113 : Pemadam Kebakaran
            - 110 : Kepolisian (Kriminal dll)
            - 081219071900 : BPBD (Untuk Bantuan Penanggulangan Bencana)`
    ];
    return randomResponse(responses);
}

function selesaiPenangananMessage(sapaan, nama, sessionId, formattedKesimpulan) {
    const responses = [
        `Terimakasih ${sapaan} ${nama}, Laporan ${sessionId} telah selesai ditangani.
            berikut ini adalah hasil penanganan laporannya:
            ${formattedKesimpulan}

            Apakah sudah puas dengan hasil penanganan laporan ini?
            jika belum puas, cukup balas dengan "belum"
            jika sudah puas, cukup balas dengan "puas"`
    ];
    return randomResponse(responses);
}

function ditolakMessage(sapaan, nama, sessionId, keterangan) {
    const responses = [
        `Mohon maaf ${sapaan} ${nama}, Laporan ${sessionId} ditolak dan tidak dapat ditindak lanjuti. Karena ${keterangan || "Tidak ada jalasan jelas"}, silahkan untuk membuat laporan baru dengan memperbaiki kesalahan ${keterangan || "Tidak ada alasan jelas, silahkan untuk langsung membuat laporan baru"}`
    ];
    return randomResponse(responses);
}

module.exports = {
    daruratMessage,
    selesaiPenangananMessage,
    ditolakMessage
};