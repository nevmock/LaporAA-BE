function randomResponse(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function mintaKeluhan() {
    const responses = [
        `Apakah ada keluhan tambahan? Jika sudah cukup, ketik "kirim".`,
        `Silakan tambahkan keluhan lain, atau ketik "kirim" jika sudah selesai.`,
        `Tulis keluhan tambahan jika ada, atau ketik "kirim" untuk lanjut.`,
        `Jika masih ada keluhan, silakan tulis. Jika sudah, ketik "kirim".`,
        `Ketik "kirim" jika keluhan sudah lengkap, atau tulis lagi untuk menambah.`
    ];
    return randomResponse(responses);
}

function keluhanDitambahkan() {
    const responses = [
        `Keluhan ditambahkan. Jika ada lagi, silakan tulis. Jika sudah cukup, ketik "kirim".`,
        `Keluhan berhasil ditambahkan. Tulis lagi jika masih ada, atau ketik "kirim".`,
        `Keluhan Anda sudah dicatat. Tambahkan lagi atau ketik "kirim" jika selesai.`,
        `Sudah kami tambahkan keluhan Anda. Ketik "kirim" jika sudah cukup.`,
        `Keluhan masuk. Tulis lagi untuk menambah, atau "kirim" untuk lanjut.`
    ];
    return randomResponse(responses);
}

function konfirmasiKeluhan(message) {
    const responses = [
        `Saya simpulkan keluhan anda sebagai berikut: ${message}\nJika sudah sesuai, ketik "kirim" untuk lanjut ke lokasi kejadian, atau "batal" untuk mengulang.`,
        `Berikut ringkasan keluhan Anda: ${message}\nKetik "kirim" jika sudah benar, atau "batal" untuk mengulang.`,
        `Keluhan Anda: ${message}\nKetik "kirim" untuk lanjut, atau "batal" untuk mengulang.`,
        `Ringkasan keluhan: ${message}\nKetik "kirim" jika sudah sesuai, atau "batal" untuk mengulang.`,
        `Keluhan yang tercatat: ${message}\nKetik "kirim" untuk lanjut ke lokasi, atau "batal" untuk mengulang.`
    ];
    return randomResponse(responses);
}

function laporanDibatalkan(sapaan, nama) {
    const responses = [
        `Baik ${sapaan} ${nama}, laporan dibatalkan. Ketik "menu" untuk memulai kembali.`,
        `Laporan Anda dibatalkan, ${sapaan} ${nama}. Silakan ketik "menu" untuk mulai ulang.`,
        `Laporan telah dibatalkan, ${sapaan} ${nama}.`,
        `Proses laporan dibatalkan. Ketik "menu" untuk memulai lagi.`,
        `Laporan dibatalkan. Silakan mulai ulang dengan ketik "menu", ${sapaan} ${nama}.`
    ];
    return randomResponse(responses);
}

function ulangKeluhan(sapaan, nama) {
    const responses = [
        `Baik ${sapaan} ${nama}, silakan jelaskan kembali keluhan Anda.`,
        `Silakan ulangi penjelasan keluhan Anda, ${sapaan} ${nama}.`,
        `Mohon tuliskan kembali keluhan Anda, ${sapaan} ${nama}.`,
        `Ceritakan ulang keluhan Anda, ${sapaan} ${nama}.`,
        `Silakan sampaikan kembali keluhan Anda, ${sapaan} ${nama}.`
    ];
    return randomResponse(responses);
}

function konfirmasiAtauBatal() {
    const responses = [
        `Silakan ketik "kirim" jika sudah sesuai, atau "batal" untuk mengulang.`,
        `Ketik "kirim" jika sudah benar, atau "batal" untuk mengulang.`,
        `Jika sudah sesuai, ketik "kirim". Jika ingin mengulang, ketik "batal".`,
        `Ketik "kirim" untuk lanjut, atau "batal" untuk mengulang.`,
        `Silakan konfirmasi dengan "kirim", atau ulangi dengan "batal".`
    ];
    return randomResponse(responses);
}

function mintaLokasi(sapaan, nama) {
    const responses = [
        `Baik ${sapaan} ${nama}, silakan kirimkan *pin point lokasi kejadian* menggunakan fitur *Kirim Lokasi* di WhatsApp.`,
        `Silakan kirim lokasi kejadian dengan fitur *Kirim Lokasi*, ${sapaan} ${nama}.`,
        `Mohon kirimkan lokasi kejadian melalui fitur *Kirim Lokasi*, ${sapaan} ${nama}.`,
        `Kirimkan lokasi kejadian dengan fitur *Kirim Lokasi* di WhatsApp, ${sapaan} ${nama}.`,
        `Silakan gunakan fitur *Kirim Lokasi* untuk mengirim lokasi kejadian, ${sapaan} ${nama}.`
    ];
    return randomResponse(responses);
}

function lokasiBukanBekasi(sapaan, nama, kabupaten) {
    const responses = [
        `Terima kasih ${sapaan} ${nama}, laporan Anda berada di luar wilayah *Kabupaten Bekasi* (${kabupaten || "wilayah tidak dikenal"}).`,
        `Mohon maaf, lokasi laporan Anda bukan di Kabupaten Bekasi (${kabupaten || "wilayah tidak dikenal"}).`,
        `Laporan Anda tidak berada di Kabupaten Bekasi (${kabupaten || "wilayah tidak dikenal"}).`,
        `Lokasi laporan di luar Kabupaten Bekasi (${kabupaten || "wilayah tidak dikenal"}).`,
        `Laporan Anda bukan di wilayah Kabupaten Bekasi (${kabupaten || "wilayah tidak dikenal"}).`
    ];
    return randomResponse(responses) + `\n\nSilakan hubungi layanan pengaduan masyarakat di pemerintahan daerah setempat sesuai lokasi kejadian.`;
}

function lokasiDiterima(wilayah) {
    const responses = [
        `Berikut lokasi yang Anda kirim: ${wilayah.desa}, ${wilayah.kecamatan}, ${wilayah.kabupaten} Ketik "kirim" jika sudah sesuai, atau "batal" untuk kirim ulang.`,
        `Lokasi diterima: ${wilayah.desa}, ${wilayah.kecamatan}, ${wilayah.kabupaten}. Ketik "kirim" jika benar, atau "batal" untuk ulang.`,
        `Lokasi Anda: ${wilayah.desa}, ${wilayah.kecamatan}, ${wilayah.kabupaten}. Ketik "kirim" jika sudah sesuai.`,
        `Lokasi sudah kami terima: ${wilayah.desa}, ${wilayah.kecamatan}, ${wilayah.kabupaten}.`,
        `Lokasi: ${wilayah.desa}, ${wilayah.kecamatan}, ${wilayah.kabupaten}. Ketik "kirim" jika benar, atau "batal" untuk ulang.`
    ];
    return randomResponse(responses);
}

function mintaFoto() {
    const responses = [
        `Silakan kirim *1–3 foto* pendukung. Cek kembali apakah foto yang dikirim sudah jelas dan relevan.`,
        `Mohon kirimkan 1 sampai 3 foto pendukung yang relevan.`,
        `Kirimkan foto pendukung (maksimal 3). Pastikan foto jelas.`,
        `Silakan upload foto pendukung, minimal 1 dan maksimal 3.`,
        `Kirimkan foto yang mendukung laporan Anda (1–3 foto).`
    ];
    return randomResponse(responses);
}

function ulangLokasi() {
    const responses = [
        `Silakan kirim ulang lokasi kejadian dengan fitur *Kirim Lokasi* di WhatsApp.`,
        `Mohon kirim ulang lokasi kejadian menggunakan fitur *Kirim Lokasi*.`,
        `Kirim ulang lokasi kejadian dengan fitur *Kirim Lokasi* di WhatsApp.`,
        `Silakan ulangi pengiriman lokasi dengan fitur *Kirim Lokasi*.`,
        `Mohon ulangi kirim lokasi kejadian menggunakan fitur *Kirim Lokasi*.`
    ];
    return randomResponse(responses);
}

function konfirmasiLokasi() {
    const responses = [
        `Ketik "kirim" jika lokasi sudah benar, atau "batal" untuk kirim ulang.`,
        `Jika lokasi sudah sesuai, ketik "kirim". Jika ingin mengulang, ketik "batal".`,
        `Konfirmasi lokasi dengan "kirim", atau ulangi dengan "batal".`,
        `Ketik "kirim" untuk lanjut, atau "batal" untuk ulang lokasi.`,
        `Silakan ketik "kirim" jika lokasi sudah benar, atau "batal" untuk ulang.`
    ];
    return randomResponse(responses);
}

function minimalFoto(sapaan, nama) {
    const responses = [
        `Mohon maaf ${sapaan} ${nama}, minimal perlu 1 foto sebelum melanjutkan.`,
        `Minimal 1 foto diperlukan untuk melanjutkan, ${sapaan} ${nama}.`,
        `Anda harus mengirimkan setidaknya 1 foto, ${sapaan} ${nama}.`,
        `Tidak bisa lanjut tanpa foto, ${sapaan} ${nama}.`,
        `Mohon kirim minimal 1 foto pendukung, ${sapaan} ${nama}.`
    ];
    return randomResponse(responses);
}

function ringkasanLaporan(session) {
    const responses = [
        `Berikut ringkasan laporan Anda:\n📍 Lokasi: ${session.location.desa}, ${session.location.kecamatan}, ${session.location.kabupaten}\n📝 Keluhan:\n${session.message}\n📷 Jumlah Foto: ${session.photos.length}\nJika sudah benar, ketik "konfirmasi" untuk mengirim atau "batal" untuk mengulang.`,
        `Ringkasan laporan:\nLokasi: ${session.location.desa}, ${session.location.kecamatan}, ${session.location.kabupaten}\nKeluhan:\n${session.message}\nJumlah Foto: ${session.photos.length}\nKetik "konfirmasi" jika sudah benar, atau "batal" untuk mengulang.`,
        `Cek kembali laporan Anda:\nLokasi: ${session.location.desa}, ${session.location.kecamatan}, ${session.location.kabupaten}\nKeluhan:\n${session.message}\nFoto: ${session.photos.length}\nKetik "konfirmasi" untuk kirim, atau "batal" untuk ulang.`,
        `Berikut detail laporan Anda:\nLokasi: ${session.location.desa}, ${session.location.kecamatan}, ${session.location.kabupaten}\nKeluhan:\n${session.message}\nJumlah Foto: ${session.photos.length}\nKetik "konfirmasi" jika sudah benar.`,
        `Laporan Anda:\nLokasi: ${session.location.desa}, ${session.location.kecamatan}, ${session.location.kabupaten}\nKeluhan:\n${session.message}\nFoto: ${session.photos.length}\nKetik "konfirmasi" untuk kirim, atau "batal" untuk ulang.`
    ];
    return randomResponse(responses);
}

function laporanDibatalkanMenu() {
    const responses = [
        `Laporan dibatalkan. Ketik "menu" untuk memulai kembali.`,
        `Proses laporan dibatalkan. Silakan ketik "menu" untuk mulai ulang.`,
        `Laporan telah dibatalkan. Ketik "menu" untuk memulai lagi.`,
        `Laporan dibatalkan. Silakan mulai ulang dengan ketik "menu".`,
        `Laporan Anda dibatalkan. Ketik "menu" untuk mulai dari awal.`
    ];
    return randomResponse(responses);
}

function hanyaFoto() {
    const responses = [
        `Mohon hanya kirim foto atau ketik "kirim" jika sudah cukup, atau "batal" untuk mengulang.`,
        `Silakan kirim foto saja, atau ketik "kirim" jika sudah selesai.`,
        `Kirim hanya foto, atau ketik "kirim" untuk lanjut, "batal" untuk ulang.`,
        `Mohon kirimkan foto saja, atau ketik "kirim"/"batal".`,
        `Hanya foto yang diterima, atau ketik "kirim" jika sudah cukup.`
    ];
    return randomResponse(responses);
}

function gagalProsesFoto() {
    const responses = [
        `Kami tidak dapat memproses foto tersebut. Coba kirim ulang menggunakan fitur "Kirim Foto".`,
        `Foto gagal diproses. Silakan kirim ulang dengan fitur "Kirim Foto".`,
        `Gagal memproses foto. Mohon kirim ulang fotonya.`,
        `Foto tidak bisa diproses. Silakan coba lagi.`,
        `Foto gagal diproses. Coba kirim ulang menggunakan fitur "Kirim Foto".`
    ];
    return randomResponse(responses);
}

function sudah3Foto() {
    const responses = [
        `Kami telah menerima 3 foto. Coba periksa kembali, apakah foto yang Anda kirim sudah sesuai? Jika sudah, ketik "kirim", atau ketik "batal" untuk mengulang.`,
        `Sudah ada 3 foto yang diterima. Ketik "kirim" jika sudah cukup, atau "batal" untuk ulang.`,
        `Maksimal 3 foto. Ketik "kirim" jika sudah benar, atau "batal" untuk ulang.`,
        `Sudah menerima 3 foto. Silakan cek kembali, lalu ketik "kirim" atau "batal".`,
        `Sudah 3 foto diterima. Ketik "kirim" jika sudah cukup, atau "batal" untuk ulang.`
    ];
    return randomResponse(responses);
}

function fotoBerhasilDiterima(sisa) {
    const responses = [
        `Foto berhasil diterima. Masih bisa kirim ${sisa} foto lagi. Ketik "kirim" jika sudah cukup, atau "batal" untuk mengulang.`,
        `Foto masuk. Anda masih bisa mengirim ${sisa} foto lagi.`,
        `Foto diterima. Sisa foto yang bisa dikirim: ${sisa}.`,
        `Foto sudah diterima. Masih bisa tambah ${sisa} foto lagi.`,
        `Foto berhasil diupload. Masih bisa kirim ${sisa} foto lagi.`
    ];
    return randomResponse(responses);
}

function konfirmasiReview() {
    const responses = [
        `Ketik "konfirmasi" jika laporan sudah benar, atau "batal" untuk membatalkan.`,
        `Konfirmasi laporan dengan ketik "konfirmasi", atau "batal" untuk membatalkan.`,
        `Jika laporan sudah benar, ketik "konfirmasi". Jika ingin membatalkan, ketik "batal".`,
        `Ketik "konfirmasi" untuk kirim laporan, atau "batal" untuk membatalkan.`,
        `Silakan ketik "konfirmasi" jika sudah benar, atau "batal" untuk membatalkan.`
    ];
    return randomResponse(responses);
}

function laporanBerhasil(sapaan, nama, nomorLaporan) {
    const responses = [
        `Terima kasih ${sapaan} ${nama}, laporan berhasil dikirim dengan ID ${nomorLaporan}. Simpan ID ini untuk cek status laporan.`,
        `Laporan Anda sudah berhasil dikirim, ${sapaan} ${nama}. ID: ${nomorLaporan}.`,
        `Laporan berhasil dikirim dengan ID ${nomorLaporan}, ${sapaan} ${nama}.`,
        `Terima kasih, laporan Anda sudah kami terima. ID: ${nomorLaporan}.`,
        `Laporan berhasil dikirim. Simpan ID ${nomorLaporan} untuk cek status, ${sapaan} ${nama}.`
    ];
    return randomResponse(responses);
}

function gagalSimpanLaporan() {
    const responses = [
        `Terjadi kesalahan saat menyimpan laporan. Silakan ketik "reset" untuk mengulang.`,
        `Laporan gagal disimpan. Silakan coba lagi dengan ketik "reset".`,
        `Gagal menyimpan laporan. Silakan ulangi proses dengan "reset".`,
        `Ada kendala saat menyimpan laporan. Silakan ketik "reset" untuk mengulang.`,
        `Laporan tidak berhasil disimpan. Silakan coba lagi dengan "reset".`
    ];
    return randomResponse(responses);
}

function ulangLaporan() {
    const responses = [
        `Laporan dibatalkan. Ketik "menu" untuk memulai dari awal.`,
        `Proses laporan dibatalkan. Silakan mulai ulang dengan ketik "menu".`,
        `Laporan telah dibatalkan. Ketik "menu" untuk mulai dari awal.`,
        `Laporan Anda dibatalkan. Silakan mulai ulang dengan "menu".`,
        `Laporan dibatalkan. Ketik "menu" untuk mulai ulang.`
    ];
    return randomResponse(responses);
}

function handlerDefault() {
    const responses = [
        `Anda di createReportHandler.`,
        `Create report handler aktif.`,
        `Silakan lanjutkan proses pembuatan laporan.`,
        `Proses pembuatan laporan sedang berjalan.`,
        `Handler create report aktif, silakan lanjutkan.`
    ];
    return randomResponse(responses);
}

module.exports = {
    mintaKeluhan,
    keluhanDitambahkan,
    konfirmasiKeluhan,
    laporanDibatalkan,
    ulangKeluhan,
    konfirmasiAtauBatal,
    mintaLokasi,
    lokasiBukanBekasi,
    lokasiDiterima,
    mintaFoto,
    ulangLokasi,
    konfirmasiLokasi,
    minimalFoto,
    ringkasanLaporan,
    laporanDibatalkanMenu,
    hanyaFoto,
    gagalProsesFoto,
    sudah3Foto,
    fotoBerhasilDiterima,
    konfirmasiReview,
    laporanBerhasil,
    gagalSimpanLaporan,
    ulangLaporan,
    handlerDefault,
};