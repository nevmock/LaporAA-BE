function randomResponse(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function belumTerdaftar() {
    const responses = [
        `Data diri Anda belum terdaftar di sistem kami. Silakan masukkan nama lengkap sesuai KTP sebelum membuat laporan.`,
        `Anda belum terdaftar. Mohon isi nama lengkap sesuai KTP untuk melanjutkan.`,
        `Nama Anda belum ada di sistem. Masukkan nama lengkap KTP agar bisa membuat laporan.`,
        `Sebelum membuat laporan, silakan daftarkan nama lengkap Anda sesuai KTP.`,
        `Data belum ditemukan. Masukkan nama lengkap KTP untuk proses selanjutnya.`
    ];
    return randomResponse(responses);
}

function mulaiLaporan(sapaan, nama) {
    const responses = [
        `Silakan ${sapaan} ${nama}, ceritakan keluhan atau kejadian yang ingin Anda laporkan.`,
        `Yuk, ${sapaan} ${nama}, tuliskan keluhan atau kejadian yang ingin dilaporkan.`,
        `Silakan sampaikan keluhan Anda, ${sapaan} ${nama}.`,
        `Ceritakan masalah atau kejadian yang ingin dilaporkan, ${sapaan} ${nama}.`,
        `Tulis keluhan atau kejadian yang ingin Anda laporkan, ${sapaan} ${nama}.`
    ];
    return randomResponse(responses);
}

function cekBelumTerdaftar() {
    const responses = [
        `Belum ada laporan terdaftar di sistem kami. Silakan buat laporan terlebih dahulu.`,
        `Maaf, Anda belum memiliki laporan yang bisa dicek. Silakan buat laporan baru.`,
        `Tidak ditemukan laporan terdaftar. Silakan buat laporan sebelum melakukan pengecekan.`,
        `Sistem belum menemukan laporan Anda. Silakan buat laporan terlebih dahulu.`,
        `Belum ada data laporan. Silakan buat laporan untuk bisa melakukan pengecekan.`
    ];
    return randomResponse(responses);
}

function mintaIdLaporan(sapaan, nama) {
    const responses = [
        `Silakan ${sapaan} ${nama}, masukkan *ID laporan* Anda. Contoh: 12345678.`,
        `Masukkan ID laporan Anda, ${sapaan} ${nama}. Contoh: 12345678.`,
        `Tolong ketikkan ID laporan Anda, ${sapaan} ${nama}.`,
        `Mohon masukkan ID laporan Anda, ${sapaan} ${nama}.`,
        `Silakan input ID laporan Anda, ${sapaan} ${nama}, misal: 12345678.`
    ];
    return randomResponse(responses);
}

function mainMenuDefault() {
    const responses = [
        `Anda berada di main menu handler.`,
        `Ini adalah main menu. Silakan pilih aksi selanjutnya.`,
        `Main menu aktif. Silakan lanjutkan dengan pilihan Anda.`,
        `Selamat datang di main menu handler.`,
        `Main menu: silakan pilih ingin membuat laporan atau cek status laporan.`
    ];
    return randomResponse(responses);
}

module.exports = {
    belumTerdaftar,
    mulaiLaporan,
    cekBelumTerdaftar,
    mintaIdLaporan,
    mainMenuDefault,
};